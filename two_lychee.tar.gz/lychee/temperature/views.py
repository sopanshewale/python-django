from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def index(request):
    #return HttpResponse("Hello, world. You are developing Temerature Application")
    return render(request, 'index.html')

def about(request):
    return HttpResponse("The Web Application is owned by Data Science Folks at Aegis")

