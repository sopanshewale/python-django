from django import forms
from temperature.models import Temperature


class TemperatureForm (forms.ModelForm):
    class Meta:
        model = Temperature
        fields = ('temperature', 'min_temp', 'max_temp')
 
