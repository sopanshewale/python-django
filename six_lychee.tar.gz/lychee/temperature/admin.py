from django.contrib import admin

from temperature.models import Temperature
admin.site.register(Temperature)

